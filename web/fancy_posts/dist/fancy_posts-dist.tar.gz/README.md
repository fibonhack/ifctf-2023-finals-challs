# fancy_posts

> IFCTF 2023

## How to run

```shell
cp .env.example .env

# modify .env

docker-compose up --build
```
